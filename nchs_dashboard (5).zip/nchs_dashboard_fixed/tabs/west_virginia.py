"""
tabs/west_virginia.py  —  Caso de Estudio: West Virginia
El estado con la mayor tasa de mortalidad por lesiones no intencionales del país.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import dash_bootstrap_components as dbc
from dash import dcc, html
import plotly.graph_objects as go
import plotly.express as px
from data.loader import load_df, CAUSA_COLORES


def layout():
    df  = load_df()
    wv  = df[df["State"] == "West Virginia"].copy()
    nat = df[df["State"] == "United States"].copy()

    header = html.Div([
        html.H2("🔍 Caso: West Virginia", className="fw-bold mb-1", style={"color": "#3a3a5c"}),
        html.P("El estado que lidera la crisis de opioides: análisis en profundidad.",
               className="text-muted lead"),
        html.Hr(style={"borderColor": "#f0d4b8"}),
    ], className="mb-4")

    # ── KPIs destacados ──
    inj_wv_17  = wv[(wv["Cause Name"]=="Unintentional injuries") & (wv["Year"]==2017)]["Rate"].values[0]
    inj_us_17  = nat[(nat["Cause Name"]=="Unintentional injuries") & (nat["Year"]==2017)]["Rate"].values[0]
    sui_wv_17  = wv[(wv["Cause Name"]=="Suicide") & (wv["Year"]==2017)]["Rate"].values[0]
    inj_wv_99  = wv[(wv["Cause Name"]=="Unintentional injuries") & (wv["Year"]==1999)]["Rate"].values[0]
    ratio      = inj_wv_17 / inj_us_17

    kpis = dbc.Row([
        _kpi("🚨", "Tasa lesiones WV 2017",   f"{inj_wv_17:.1f}",  "por 100,000 hab.", "#ffe5e5"),
        _kpi("🇺🇸", "Tasa lesiones EE.UU. 2017", f"{inj_us_17:.1f}", "por 100,000 hab.", "#f5f3ff"),
        _kpi("📐", "Ratio WV / Nacional",     f"{ratio:.1f}x",      "veces el promedio", "#fef9e7"),
        _kpi("📈", "Aumento WV 1999→2017",    f"+{((inj_wv_17-inj_wv_99)/inj_wv_99*100):.0f}%",
             "lesiones no intencionales", "#fff0f6"),
    ], className="mb-4")

    alerta = dbc.Alert([
        html.Strong("🚨 West Virginia ocupa el primer lugar nacional "),
        f"en tasa de mortalidad por lesiones no intencionales desde 2006. En 2017 su tasa "
        f"({inj_wv_17:.1f}/100k) fue {ratio:.1f}x el promedio nacional ({inj_us_17:.1f}/100k). "
        "Este patrón está directamente vinculado a la crisis de opioides y al colapso "
        "de la industria carbonífera en la región de los Apalaches."
    ], color="danger", className="mb-4", style={"borderRadius": "8px"})

    # ── Gráfico 1: WV vs Nacional — todas las causas ──
    causas_plot = ["Heart disease", "Cancer", "Unintentional injuries", "Suicide", "CLRD", "Stroke"]
    fig_comp = go.Figure()
    for causa in causas_plot:
        wv_sub  = wv[(wv["Cause Name"]==causa)].sort_values("Year")
        nat_sub = nat[(nat["Cause Name"]==causa)].sort_values("Year")
        color   = CAUSA_COLORES.get(causa, "#aaa")
        fig_comp.add_trace(go.Scatter(
            x=wv_sub["Year"], y=wv_sub["Rate"],
            mode="lines", name=f"WV — {causa}",
            line=dict(color=color, width=2.5),
            legendgroup=causa,
            hovertemplate=f"WV — {causa}<br>%{{x}}: %{{y:.1f}}<extra></extra>",
        ))
        fig_comp.add_trace(go.Scatter(
            x=nat_sub["Year"], y=nat_sub["Rate"],
            mode="lines", name=f"EE.UU. — {causa}",
            line=dict(color=color, width=1.2, dash="dot"),
            legendgroup=causa,
            showlegend=False,
            hovertemplate=f"EE.UU. — {causa}<br>%{{x}}: %{{y:.1f}}<extra></extra>",
        ))
    fig_comp.update_layout(
        title="WV (línea sólida) vs Nacional (punteada) — principales causas",
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="sans-serif", size=11, color="#3a3a5c"),
        margin=dict(l=40, r=20, t=50, b=30),
        xaxis=dict(title="Año", dtick=2, gridcolor="#f0f0f0"),
        yaxis=dict(title="Tasa/100k", gridcolor="#f0f0f0"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1,
                    font=dict(size=9)),
        hovermode="x unified",
    )

    # ── Gráfico 2: Perfil completo WV 2017 vs Nacional ──
    wv_17  = wv[(wv["Year"]==2017) & (wv["Cause Name"]!="All causes")].sort_values("Rate", ascending=False)
    nat_17 = nat[(nat["Year"]==2017) & (nat["Cause Name"]!="All causes")].set_index("Cause Name")["Rate"]

    fig_perfil = go.Figure()
    fig_perfil.add_trace(go.Bar(
        name="West Virginia",
        x=wv_17["Cause Name"], y=wv_17["Rate"],
        marker_color="#f0b8b8",
        hovertemplate="%{x}<br>WV: %{y:.1f}/100k<extra></extra>",
    ))
    fig_perfil.add_trace(go.Bar(
        name="EE.UU.",
        x=wv_17["Cause Name"],
        y=[nat_17.get(c, 0) for c in wv_17["Cause Name"]],
        marker_color="#c5b8f0",
        hovertemplate="%{x}<br>EE.UU.: %{y:.1f}/100k<extra></extra>",
    ))
    fig_perfil.update_layout(
        barmode="group",
        title="Perfil de mortalidad 2017: West Virginia vs Promedio Nacional",
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="sans-serif", size=11, color="#3a3a5c"),
        margin=dict(l=40, r=20, t=50, b=80),
        xaxis=dict(title="", tickangle=-25),
        yaxis=dict(title="Tasa/100k", gridcolor="#f0f0f0"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )

    # ── Gráfico 3: Evolución Deaths of Despair WV ──
    despair_wv = wv[wv["Cause Name"].isin(["Suicide", "Unintentional injuries"])].sort_values("Year")
    fig_despair = go.Figure()
    for causa in ["Suicide", "Unintentional injuries"]:
        sub = despair_wv[despair_wv["Cause Name"]==causa]
        fig_despair.add_trace(go.Scatter(
            x=sub["Year"], y=sub["Rate"],
            mode="lines+markers", name=causa,
            line=dict(color=CAUSA_COLORES.get(causa), width=2.5),
            fill="tozeroy",
            fillcolor='rgba(90,79,207,0.15)',
        ))
    fig_despair.update_layout(
        title="Deaths of Despair en West Virginia (1999–2017)",
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="sans-serif", size=11, color="#3a3a5c"),
        margin=dict(l=40, r=20, t=50, b=30),
        xaxis=dict(title="Año", dtick=2, gridcolor="#f0f0f0"),
        yaxis=dict(title="Tasa/100k", gridcolor="#f0f0f0"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        hovermode="x unified",
    )

    graficos_fila1 = dbc.Row([
        dbc.Col(_wrap(fig_comp, 420), md=12, className="mb-3"),
    ])
    graficos_fila2 = dbc.Row([
        dbc.Col(_wrap(fig_perfil, 360), md=7, className="mb-3"),
        dbc.Col(_wrap(fig_despair, 360), md=5, className="mb-3"),
    ])

    contexto = dbc.Card([
        dbc.CardHeader(html.H5("📰 Contexto: ¿Por qué West Virginia?",
                               className="mb-0 fw-bold", style={"color": "#3a3a5c"})),
        dbc.CardBody(dbc.Row([
            dbc.Col(_info("⛏️", "Colapso del carbón",
                "La desindustrialización de la industria carbonífera dejó a decenas de miles "
                "sin empleo. WV tiene una de las tasas de desempleo más altas y la mayor "
                "proporción de trabajadores en minería del país."), md=3),
            dbc.Col(_info("💊", "Epicentro opiáceo",
                "Distribuidoras farmacéuticas enviaron millones de pastillas opioides a WV "
                "en proporción desproporcionada. En 2016, McDowell County recibió 1,000 "
                "pastillas por persona/año."), md=3),
            dbc.Col(_info("🏥", "Sistema de salud frágil",
                "WV tiene una de las peores coberturas de salud mental y tratamiento de "
                "adicciones del país. La ruralidad extrema dificulta el acceso a centros "
                "especializados de desintoxicación."), md=3),
            dbc.Col(_info("📉", "Pobreza estructural",
                "Con más del 17% de su población bajo la línea de pobreza y el menor "
                "ingreso per cápita de EE.UU., WV concentra todos los factores de riesgo "
                "asociados a las Deaths of Despair."), md=3),
        ]))
    ], className="shadow-sm border-0 mb-4", style={"borderRadius": "12px"})

    return dbc.Container([
        html.Br(), header, alerta, kpis, graficos_fila1, graficos_fila2, contexto, html.Br()
    ], fluid=True)


def _kpi(icon, titulo, valor, sub, bg):
    return dbc.Col(dbc.Card([dbc.CardBody([
        html.Div(icon, className="fs-2 mb-1"),
        html.H6(titulo, className="text-muted small"),
        html.H4(valor, className="fw-bold mb-0", style={"color": "#c94f4f"}),
        html.Small(sub, className="text-muted"),
    ], className="text-center")], className="h-100 shadow-sm border-0",
        style={"background": bg, "borderRadius": "12px"}), md=3, className="mb-3")


def _wrap(fig, height=380):
    return dbc.Card(
        dcc.Graph(figure=fig, config={"displayModeBar": False},
                  style={"height": f"{height}px"}),
        className="shadow-sm border-0 p-2", style={"borderRadius": "12px"}
    )


def _info(icon, titulo, desc):
    return html.Div([
        html.P(icon + " " + titulo, className="fw-bold small mb-1", style={"color": "#3a3a5c"}),
        html.P(desc, className="text-muted small mb-0"),
    ])
