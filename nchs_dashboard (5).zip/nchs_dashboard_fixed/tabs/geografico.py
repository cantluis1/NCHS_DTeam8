"""
tabs/geografico.py  —  Análisis Geográfico (mapa coroplético)
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import dash_bootstrap_components as dbc
from dash import dcc, html, Input, Output, callback
import plotly.express as px
import plotly.graph_objects as go
from data.loader import load_df


def layout():
    df    = load_df()
    causas = sorted([c for c in df["Cause Name"].unique() if c != "All causes"]) + ["All causes"]
    años   = sorted(df["Year"].unique())

    header = html.Div([
        html.H2("🗺️ Análisis Geográfico", className="fw-bold mb-1", style={"color": "#3a3a5c"}),
        html.P("Mapa coroplético interactivo: distribución geográfica de la mortalidad en EE.UU.",
               className="text-muted lead"),
        html.Hr(style={"borderColor": "#d4f0b8"}),
    ], className="mb-4")

    controles = dbc.Card([
        dbc.CardBody(dbc.Row([
            dbc.Col([
                dbc.Label("🦠 Causa de muerte", className="fw-semibold small"),
                dcc.Dropdown(
                    id="geo-causa",
                    options=[{"label": c, "value": c} for c in causas],
                    value="Unintentional injuries",
                    clearable=False,
                    style={"fontSize": "0.9rem"},
                ),
            ], md=5),
            dbc.Col([
                dbc.Label("📅 Año", className="fw-semibold small"),
                dcc.Slider(
                    id="geo-año",
                    min=int(min(años)), max=int(max(años)), step=1,
                    value=2017,
                    marks={int(y): str(y) for y in años if int(y) % 3 == 0 or y in [min(años), max(años)]},
                    tooltip={"placement": "bottom", "always_visible": True},
                ),
            ], md=5),
            dbc.Col([
                dbc.Label("🎨 Escala", className="fw-semibold small"),
                dbc.RadioItems(
                    id="geo-escala",
                    options=[
                        {"label": " Reds", "value": "Reds"},
                        {"label": " Blues", "value": "Blues"},
                        {"label": " Plasma", "value": "Plasma"},
                    ],
                    value="Reds",
                    inline=True,
                    className="small mt-1",
                ),
            ], md=2),
        ]))
    ], className="shadow-sm border-0 mb-3", style={"borderRadius": "12px"})

    mapa = dbc.Card(
        dcc.Graph(id="geo-map", config={"displayModeBar": True},
                  style={"height": "480px"}),
        className="shadow-sm border-0 p-2 mb-3", style={"borderRadius": "12px"}
    )

    fila_inf = dbc.Row([
        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H6("Tasa vs Muertes absolutas (burbujas)",
                                   className="mb-0 fw-bold", style={"color": "#3a3a5c"})),
            dbc.CardBody(dcc.Graph(id="geo-scatter", config={"displayModeBar": True, "scrollZoom": True},
                                   style={"height": "300px"})),
        ], className="shadow-sm border-0", style={"borderRadius": "12px"}), md=6),
        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H6("Ranking de estados — año seleccionado",
                                   className="mb-0 fw-bold", style={"color": "#3a3a5c"})),
            dbc.CardBody(dcc.Graph(id="geo-bar", config={"displayModeBar": False},
                                   style={"height": "300px"})),
        ], className="shadow-sm border-0", style={"borderRadius": "12px"}), md=6),
    ], className="mb-4")

    return dbc.Container([html.Br(), header, controles, mapa, fila_inf, html.Br()], fluid=True)


@callback(
    Output("geo-map",     "figure"),
    Output("geo-scatter", "figure"),
    Output("geo-bar",     "figure"),
    Input("geo-causa", "value"),
    Input("geo-año",   "value"),
    Input("geo-escala","value"),
)
def update_geo(causa, año, escala):
    df  = load_df()
    dff = df[(df["Cause Name"] == causa) & (df["Year"] == año) &
             (df["State"] != "United States") & df["StateCode"].notna()].copy()

    # ── Mapa coroplético ──
    fig_map = px.choropleth(
        dff,
        locations="StateCode",
        locationmode="USA-states",
        color="Rate",
        color_continuous_scale=escala,
        scope="usa",
        hover_name="State",
        hover_data={"Rate": ":.1f", "Deaths": ":,", "StateCode": False},
        labels={"Rate": "Tasa/100k", "Deaths": "Muertes"},
        title=f"{causa} — {año}",
    )
    fig_map.update_layout(
        geo=dict(showlakes=True, lakecolor="rgb(220,240,255)"),
        coloraxis_colorbar=dict(title="Tasa/100k", thickness=14),
        margin=dict(l=0, r=0, t=50, b=0),
        font=dict(family="sans-serif", size=11, color="#3a3a5c"),
        paper_bgcolor="white",
    )

    # ── Bubble chart tasa vs muertes ──
    import numpy as np
    # Tamaño de burbuja: raíz cuadrada de muertes para escalar visualmente
    bubble_size = np.sqrt(dff["Deaths"].clip(lower=1)).values
    bubble_size = (bubble_size / bubble_size.max() * 55 + 10).tolist()

    fig_scat = go.Figure()
    fig_scat.add_trace(go.Scatter(
        x=dff["Deaths"],
        y=dff["Rate"],
        mode="markers+text",
        text=dff["StateCode"],
        textposition="top center",
        marker=dict(
            size=bubble_size,
            color=dff["Rate"],
            colorscale=escala,
            showscale=True,
            colorbar=dict(title="Tasa/100k", thickness=12),
            opacity=0.75,
            line=dict(color="white", width=1.5),
        ),
        customdata=dff[["State", "Deaths", "Rate"]].values,
        hovertemplate=(
            "<b>%{customdata[0]}</b><br>"
            "Muertes: %{customdata[1]:,}<br>"
            "Tasa: %{customdata[2]:.1f}/100k<extra></extra>"
        ),
    ))
    fig_scat.update_layout(
        **_lbase(),
        title=f"Tasa vs Muertes (burbujas) — {año}",
        xaxis=dict(title="Muertes absolutas", gridcolor="#f0f0f0"),
        yaxis=dict(title="Tasa/100k", gridcolor="#f0f0f0"),
        margin=dict(l=40, r=20, t=40, b=40),
        dragmode="zoom",
    )

    # ── Barplot top 15 estados ──
    top15 = dff.nlargest(15, "Rate").sort_values("Rate")
    colores = ["#f0b8b8" if s == "West Virginia" else "#c5b8f0" for s in top15["State"]]
    fig_bar = go.Figure(go.Bar(
        x=top15["Rate"], y=top15["State"], orientation="h",
        marker_color=colores,
        text=top15["Rate"].apply(lambda x: f"{x:.1f}"),
        textposition="outside",
        hovertemplate="%{y}: %{x:.1f}/100k<extra></extra>",
    ))
    fig_bar.update_layout(**_lbase(), xaxis_title="Tasa/100k",
                          title=f"Top 15 estados — {año}",
                          margin=dict(l=130, r=50, t=40, b=30))

    return fig_map, fig_scat, fig_bar


def _lbase():
    return dict(
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="sans-serif", size=11, color="#3a3a5c"),
    )
